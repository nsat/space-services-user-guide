# -*- coding: utf-8; fill-column: 77 -*-
# -*- indent-tabs-mode: nil -*-
"""
Library of useful Python functions and classes.
"""

from ._version import get_versions
__version__ = get_versions()['version']
del get_versions
